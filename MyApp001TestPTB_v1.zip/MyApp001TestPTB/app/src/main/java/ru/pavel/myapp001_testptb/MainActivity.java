package ru.pavel.myapp001_testptb;

import android.content.res.Resources;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Random;


public class MainActivity extends AppCompatActivity {

    //private static final String FILENAME = "file";
    private static final String TAG = "MyApp";
    private static final String FILE_NAME = "quiz.txt";

    private String fileQuiz;

    TextView mTvTest;
    TextView mTvQuestion;
    TextView mTvWrong;
    TextView mTvRight;
    Button mButton;
    CheckBox mChAnswer1;
    CheckBox mChAnswer2;
    CheckBox mChAnswer3;
    CheckBox mChAnswer4;
    CheckBox mChAnswer5;
    CheckBox mChAnswer6;
    //ArrayList<CheckBox> mAnswers = new ArrayList<>();
    CheckBox[] mChAnswers;

    boolean viewNewQuestion = true;

    View.OnClickListener onClickNextButton = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            log("Button pressed");
            if (viewNewQuestion){
                doQuiz(pointQuestions.get(randomPointQuestion()));
                randomPointQuestion();
                drawQuestion();
            }else{
                checkAnswersAndDrawRight();
            }
            viewNewQuestion = !viewNewQuestion;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mTvTest = (TextView) findViewById(R.id.mTvInfo);
        mTvQuestion = findViewById(R.id.mTvQuestin);
        mButton = findViewById(R.id.mBtNext);
        mChAnswer1 = (CheckBox) findViewById(R.id.mCbAnswer1);
        mChAnswer2 = (CheckBox) findViewById(R.id.mCbAnswer2);
        mChAnswer3 = (CheckBox) findViewById(R.id.mCbAnswer3);
        mChAnswer4 = (CheckBox) findViewById(R.id.mCbAnswer4);
        mChAnswer5 = findViewById(R.id.mCbAnswer5);
        mChAnswer6 = findViewById(R.id.mCbAnswer6);
        mChAnswers = new CheckBox[] {mChAnswer1,mChAnswer2,mChAnswer3,mChAnswer4,mChAnswer5,mChAnswer6};

        mTvWrong = findViewById(R.id.tvWrong);
        mTvRight = findViewById(R.id.tvRight);



        //writeFile();
        //fileQuiz = readQuizFiles();
        fileQuiz = readQuizRaw();
        searchAllQuestions();
        doQuiz(0);
        drawQuestion();


        mButton.setOnClickListener(onClickNextButton);


    }

    void writeFile() {
        try {
            // отрываем поток для записи
            BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(
                    openFileOutput(FILE_NAME, MODE_PRIVATE)));
            // пишем данные
            bw.write("Содержимое файла \r\n Новая строка \n");
            // закрываем поток
            bw.close();
            Log.i(TAG, "Файл записан");
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    String readQuizFiles() {
        FileInputStream file = null;
        String text = null;
        try {
            file = openFileInput(FILE_NAME);
            byte[] bytes = new byte[file.available()];
            file.read(bytes);
            text = new String(bytes);
            Log.i(TAG, text);
        }
        catch(IOException ex) {

            Toast.makeText(this, ex.getMessage(), Toast.LENGTH_SHORT).show();
        }
        finally{

            try{
                if(file!=null)
                    file.close();
            }
            catch(IOException ex){

                Toast.makeText(this, ex.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }
        return text;

    }
    //read text file with quiz
    String readQuizRaw(){
        String text = null;
        Resources res = this.getResources();
        InputStream file = res.openRawResource(R.raw.quiz1);
        try {
            byte[] bytes = new byte[file.available()];
            file.read(bytes);
            text = new String(bytes);
        }
        catch(IOException ex){
        }
        try {
            file.close();
        }
        catch (IOException e){
        }
        return text;
    }

    //test method for parse quiz for question and answer
    boolean[] answerMark = new boolean[10];
    String[] answerText = new String[10];
    String question;
    // in - fileQuiz - search questions and answers
    // line is start point for search QUESTION
    void doQuiz(int line){
        int countAnswer=0;
        char chLookFor;
        int pointStartQuestion;
        int pointEndQuestion;
        boolean searchQuestion = true;
        boolean searchTicket = true;
        boolean searchText = true;
        boolean newLine = true;
        answerText = new String[10];

        for (int i=line; (i<fileQuiz.length())&&searchTicket; i++){
            chLookFor = fileQuiz.charAt(i);
            if (chLookFor=='\n'){
                newLine = true;
            }
            if ((chLookFor == '?')&&(searchQuestion)){
                newLine = false;
                Log.i(TAG, "Вопрос найден");

                while(chLookFor!='\n'){
                    i++;
                    chLookFor = fileQuiz.charAt(i);
                }
                i++;
                pointStartQuestion = i;
                for (searchText = true;(i<fileQuiz.length())&&searchText; i++){
                    chLookFor = fileQuiz.charAt(i);
                    if (chLookFor == '\n'){
                        pointEndQuestion = i;
                        question = fileQuiz.substring(pointStartQuestion, pointEndQuestion);
                        searchText = false;
                        searchQuestion = false;
                    }
                }
            }
            if ((chLookFor=='-')||(chLookFor=='+')){
                newLine = false;
                Log.i(TAG,"Найден ответ "+countAnswer);
                if (chLookFor=='-') answerMark[countAnswer]=false;
                if (chLookFor=='+') answerMark[countAnswer]=true;
                pointStartQuestion = i+1;

                for(searchText = true;(i<fileQuiz.length())&&searchText; i++){
                    chLookFor = fileQuiz.charAt(i);
                    if (chLookFor == '\n'){
                        pointEndQuestion = i;
                        answerText[countAnswer] = fileQuiz.substring(pointStartQuestion, pointEndQuestion);
                        countAnswer++;
                        searchText = false;
                        i--;
                    }
                }
            }
            if((chLookFor=='?')&&newLine) searchTicket = false;
        }

        //view result in log
        Log.i(TAG, question);
        for (int i=0;i<10;i++){
            if (answerText[i]==null) return;
            //if (answerText[i].isEmpty()) return;
            Log.i(TAG, answerMark[i]+"  "+answerText[i]);
        }
    }

    ArrayList<Integer> pointQuestions = new ArrayList<>();
    void searchAllQuestions(){
        boolean newLine = true;
        char chLookFor;
        for (int i=1; i<fileQuiz.length(); i++){
            chLookFor = fileQuiz.charAt(i);
            if ((chLookFor=='?')&&newLine){
                pointQuestions.add(i);
            }else if (chLookFor=='\n'){
                newLine=true;
            }else if (chLookFor!=' '){
                newLine=false;
            }

        }
        Log.i(TAG, "Вопросов найдено : "+pointQuestions.size());
    }
    void log(String text){
        Log.i(TAG,text);
    }


    int randomPointQuestion (){
        int random = 0;
        if(pointQuestions.size()>3){
            Random rand = new Random();
            int max = pointQuestions.size()-1;
            int min = 0;
            random = rand.nextInt(((max-min)+1)+min);
        }
        log("Random index = "+random+" of "+pointQuestions.size());
        return random;
    }

    void drawQuestion (){
        mTvQuestion.setText(question);
        mTvRight.setVisibility(View.GONE);
        mTvWrong.setVisibility(View.GONE);
        log(question);
        for (int i=0;i<mChAnswers.length;i++){
            mChAnswers[i].setTextColor(Color.parseColor(this.getResources().getString(R.color.colorAnswer)));
            mChAnswers[i].setChecked(false);
            if (answerText[i]!=null){
                mChAnswers[i].setText(answerText[i]);
                mChAnswers[i].setVisibility(View.VISIBLE);
                log(answerText[i]);
            }else {
                mChAnswers[i].setVisibility(View.GONE);
            }
        }
    }

    boolean checkAnswersAndDrawRight (){
        boolean correctAnswer;
        boolean checkAnswer;
        boolean choice = true;
        for (int i=0;(i<mChAnswers.length)&&(answerText[i]!=null);i++){
            checkAnswer = mChAnswers[i].isChecked();
            correctAnswer = answerMark[i];
            if (correctAnswer!=checkAnswer) {
                choice = false;
                if (correctAnswer == true) {
                    mChAnswers[i].setTextColor(Color.parseColor(this.getResources().getString(R.color.colorNotChoice)));
                } else {
                    mChAnswers[i].setTextColor(Color.parseColor(this.getResources().getString(R.color.colorWrongChoice)));
                }
            }
        }
        if (choice){
            mTvRight.setVisibility(View.VISIBLE);
        }else{
            mTvWrong.setVisibility(View.VISIBLE);
        }


        return choice;
    }

}
